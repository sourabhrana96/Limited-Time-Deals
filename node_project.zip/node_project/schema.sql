create table products(
    id int not null auto_increment,
    model_name varchar(255) not null ,
    primary key (id)
)

create table deals(
    id int not null auto_increment,
    deal_code varchar(32) not null unique,
    description varchar(128) not null,
    start_time DATETIME not null,
    end_time DATETIME not null,
    item_id int not null,
    max_quantity int not null,
    price int not null,
    is_active boolean default false,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    primary key (id)
)

create table claim_deals(
    deal_id int not null,
    user_id int not null,
    price int not null,
    created_at timestamp default current_timestamp,
    updated_at timestamp default current_timestamp on update current_timestamp,
    UNIQUE KEY user_deal_uk (deal_id, user_id)
)
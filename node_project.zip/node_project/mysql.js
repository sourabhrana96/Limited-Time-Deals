let mysql  = require('mysql2');
let config = require('./mysql_config.js');
let connection = mysql.createConnection(config);

async function executeQuery(sqlQuery, values){
  return new Promise((resolve, reject)=>{
    connection.query(sqlQuery, values, (err, results) => {
      console.log(sqlQuery);
      console.log(values);
        if (err) {
          console.error(`Error in mysql:  ${err.message}`);
          reject(err.message) 
        }
        console.log(`mysql query results: ${JSON.stringify(results)}`);
        resolve(results);
      });
  })
// connection.end();
}

module.exports ={
    executeQuery
}
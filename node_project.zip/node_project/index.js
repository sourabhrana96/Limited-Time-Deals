const express = require('express');
const app = express();
app.use(express.json());

const multer = require('multer');
const upload = multer();
const service = require('./service');
const dealService = require('./dealService');


const port = 3000;
// app.get('/',(req, res)=>{
//     res.status(200).send("hello wordl");
// })
app.get('/health',(req, res)=>{
    res.status(200).send("healthy server!!!");
})
// app.post('/upload',upload.single('file'),async (req,res)=>{
//     const uploadResp = await service.uploadFile(req);
//     res.send(uploadResp);
// })


app.post('/deal', async (req,res)=>{
    const body = req.body;
    const resp = await dealService.createDeal(body);
    res.send(resp);
})

app.put('/end_deal', async (req, res)=>{
    const body = req.body;
    const resp = await dealService.endDeal(body.dealId);
    res.send(resp);
})

// modify deal
app.put('/deal', async (req, res)=>{
    const body = req.body;
    const resp = await dealService.modifyDeal(body);
    res.send(resp);
})

app.post('/claim_deal', async (req, res)=>{
    const body = req.body;
    const resp = await dealService.claimDeal(body);
    res.send(resp);
})

app.get('/active_deal',async (req, res)=>{
    const resp = await dealService.getActiveDeals();
    res.status(200).send(resp);
})






app.listen(port, () => {
    console.log(`Node project app listening at http://localhost:${port}`);
});


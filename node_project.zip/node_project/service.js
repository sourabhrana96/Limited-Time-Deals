'use strict'
const fs =require('fs');


async function uploadFile(req){
    const file = req.file;
    console.log(req.file.originalname);
    let fileContent ;
    if(!file){
        return {status: "Error", msg: "File not present!"}
    }
    // read file and save
    try{
        console.log(req.file.buffer.toString());
        fs.writeFile('./upload_files/test.txt',req.file.buffer, err=>{
            if(err){
                throw Error(err);
            }else{
                console.log("successfully writen to file!!")
            }
        } )
    }catch(err){
        console.log(`error in uploading file.Error: ${err}`);
    }
    return {status: "Success", msg: "Successfully uploaded file!"}

}

module.exports ={
    uploadFile
}


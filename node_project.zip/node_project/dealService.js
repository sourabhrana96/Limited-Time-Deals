const mysqlExecutor = require('./mysql');
const moment = require('moment');
const { user } = require('./mysql_config');

async function createDeal(body) {
    console.log(body);
    const {dealCode, desc, startTime, endTime, itemId, price, maxQuantity} = body;
    const statement = ` insert into deals(deal_code, description, start_time, end_time, item_id, price, max_quantity, is_active) 
                        values (?,?,?,?,?,?,?,?);`
    const values =[dealCode, desc, startTime, endTime, itemId, price, maxQuantity, true];
    const dbResp = await mysqlExecutor.executeQuery(statement, values);
    console.log(JSON.stringify(dbResp));
    return dbResp;
}

async function endDeal(dealId){
    const statement = ` update deals set is_active = false where id=?;`
    const values =[dealId];
    const dbResp = await mysqlExecutor.executeQuery(statement, values);
    return dbResp;
}

async function modifyDeal(body){
    const {dealId, maxQuantity =null, endTime = null} = body;
    let updateCondition =``,values =[];
    if(maxQuantity !== null){
        updateCondition =  `max_quantity = ?`;
        values.push(maxQuantity);
    }
    if(endTime !== null){
        updateCondition =  `end_time = ?`;
        values.push(endTime);
    }
    const statement = ` update deals set ${updateCondition} where id= ?;`
    values.push(dealId);
    const dbResp = await mysqlExecutor.executeQuery(statement, values);
    return dbResp;
}   

async function claimDeal(body){
    const { userId, dealId, price} = body;

    // verify user deal exists or not
    const isDuplicateDeal = await verifyDuplicateDeals(userId, dealId);
    if(isDuplicateDeal === true)
        return {status: "error", msg: "user already bought the deal!"};

    const statement = `insert into claim_deals(deal_id, user_id, price) values (?,?,?);`
    const values =[dealId, userId, price];
    const dbResp = await mysqlExecutor.executeQuery(statement, values);
    return dbResp;
}

async function getActiveDeals(){
    const statement = ` select id dealId, deal_code,description,start_time, end_time, item_id, price, max_quantity
                        from deals where is_active = true and start_time <= CURRENT_TIMESTAMP() and end_time > CURRENT_TIMESTAMP();`
    const dbResp = await mysqlExecutor.executeQuery(statement, null);
    console.log(dbResp);
    return dbResp;
}

async function verifyDuplicateDeals(userId, dealId){
    const statement = ` select count(1) from claim_deals where user_id =? and deal_id =?;`
    const values =[userId, dealId];
    const resp = await mysqlExecutor.executeQuery(statement, values);
    return resp;
}

function currentDate(){
    return moment().format('YYYY-MM-DD HH:mm:ss');
}
 console.log(currentDate());
module.exports ={
    createDeal,
    endDeal,
    modifyDeal,
    claimDeal,
    getActiveDeals
}
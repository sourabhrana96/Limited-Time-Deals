let config = {
    host    : 'localhost',
    user    : 'root',
    password: 'rana1996',
    database: 'coding_test'
  };
  
  module.exports = config;